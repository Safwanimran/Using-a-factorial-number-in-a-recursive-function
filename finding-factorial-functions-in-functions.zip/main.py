# printing factorial in functions
def factorial(number):
    product = 1
    for i in range(number):
        product = product * (i+1)
    return product
    
number = int(input("Enter a number to get the factorial of: "))
factorial_function = factorial(number)


print(factorial_function)
    

   
   
   
